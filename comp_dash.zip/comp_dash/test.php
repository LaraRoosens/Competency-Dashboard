<?php
require_once("../../config.php");
global $DB;
//require_once($CFG->dirroot.'/lib/moodlelib.php');

$courseid = required_param('id', PARAM_INT);
// require_login($courseid);
// $context = context_course::instance($courseid);
// require_capability('block/analytics_graphs:viewpages', $context);

// /* Log */
// $event = \block_analytics_graphs\event\block_analytics_graphs_event_view_graph::create(array(
//     'objectid' => $courseid,
//     'context' => $context,
//     'other' => "grades_chart.php",
// ));
// $event->trigger();

$sql_ass_comp = "SELECT DISTINCT CONCAT(l.id,l.assid,COALESCE(r.competencyid, 0)) AS tempid, l.id as id,CONCAT(l.firstname, ' ', l.lastname) AS studentName, l.assid as itemid, l.itemname, CAST(l.finalgrade AS float) as finalgrade, CAST(l.rawgrademax AS float) as rawgrademax, l.courseid, COALESCE(r.path, '/0/') as path, COALESCE(r.competencyid, -1) AS competencyid, r.shortname, CONCAT(COALESCE(r.path, '/0/'),COALESCE(r.competencyid, -1), '/') AS pathComp
from 
(SELECT usr.firstname, usr.lastname,usr.id, gi.id as assid, gi.itemname, gg.finalgrade, gi.courseid, gg.rawgrademax
from mdl_grade_items as gi, mdl_grade_grades as gg, mdl_user as usr
WHERE gg.itemid = gi.id 
and usr.id = gg.userid 
and gi.itemtype = 'mod' 
and gi.courseid = '4') l
LEFT JOIN 
(SELECT distinct gi.id, gi.itemname, mc.competencyid, c.shortname, c.path
from mdl_competency_modulecomp as mc, 
mdl_course_modules as cm, 
mdl_grade_items as gi, 
mdl_competency as c,
mdl_grade_grades as gg
WHERE mc.cmid = cm.id 
and cm.instance = gi.iteminstance 
and mc.competencyid = c.id
and gg.itemid = gi.id
and gi.itemtype = 'mod') r on l.assid = r.id
ORDER BY  l.id, l.assid";

$sql_ass = "SELECT  CONCAT(usr.id,gi.id) AS tempid, usr.id, CONCAT(usr.firstname, ' ', usr.lastname) AS studentName, gi.id as itemID, gi.itemname, CAST(gg.finalgrade AS float) as finalgrade, CAST(gg.rawgrademax AS float) as rawgrademax, gi.courseid, gi.timemodified as timemodifiedUnix 
from mdl_grade_items as gi, mdl_grade_grades as gg, mdl_user as usr
WHERE gg.itemid = gi.id 
and usr.id = gg.userid 
and gi.itemtype = 'mod' 
and gi.courseid = ?
ORDER BY usr.firstname";

$sql_course = "SELECT fullname
              FROM mdl_course as c
              where c.id = ?";
$sql_framework = "SELECT id as frameworkID, shortname as frameworkNAME
from mdl_competency_framework";

$sql_comp_course = "SELECT distinct p.id, shortname, parentid, path, competencyframeworkid
from mdl_competency as p
where exists (select 1 from mdl_competency_coursecomp as cc, mdl_competency as c
WHERE cc.competencyid = c.id and cc.courseid = ?
and path like concat('%/', p.id,'/%'))
UNION
SELECT cc.competencyid, shortname, parentid, path, competencyframeworkid
from mdl_competency_coursecomp as cc, mdl_competency as c
WHERE cc.competencyid = c.id and cc.courseid = ?";

$sql_students ="SELECT
ROW_NUMBER() OVER (ORDER BY u.lastname ASC) AS No, 
u.id,
CONCAT(u.firstname, ' ', u.lastname) AS studentName
FROM
mdl_role_assignments ra
JOIN mdl_user u ON u.id = ra.userid
JOIN mdl_role r ON r.id = ra.roleid
JOIN mdl_context cxt ON cxt.id = ra.contextid
JOIN mdl_course c ON c.id = cxt.instanceid
WHERE ra.userid = u.id
AND ra.contextid = cxt.id
AND cxt.contextlevel =50
AND cxt.instanceid = c.id
AND  roleid = 5
and c.id = 4
ORDER BY u.lastname";

$result_ass_comp = $DB->get_records_sql($sql_ass_comp, array($courseid));
$result_ass = $DB->get_records_sql($sql_ass, array($courseid));
$result_course = $DB->get_records_sql($sql_course, array($courseid));

$result_framework = $DB->get_records_sql($sql_framework);
$result_comp_course = $DB->get_records_sql($sql_comp_course, array($courseid, $courseid));
$result_students = $DB->get_records_sql($sql_students, array($courseid));


if(count($result_ass_comp) > 0){
   $msg = " found!";
   $result_shortname = array_column($result_ass_comp, 'shortname');
   $course = array_column($result_course, 'fullname')[0];
   //print_r($result_ass_comp);
   //echo json_encode($result_ass_comp, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
   echo json_encode($result_ass, JSON_UNESCAPED_UNICODE );
   // echo json_encode($result_framework, JSON_UNESCAPED_UNICODE );
   //echo json_encode($result_comp_course, JSON_UNESCAPED_SLASHES);
   //echo json_encode($result_students, JSON_UNESCAPED_UNICODE);
}else{
    $msg = "No Record found";
}

 
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
  
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/highcharts-more.js"></script>
  <link rel="stylesheet" href="./style.css">
  
  <title>TeachWise</title>

</head>

<body style="height: 100vh; max-height:100vh">
  <header style="height: 10%">
    <div class="row">
      <div class="col">
        <div class="logo">
          Competence dashboard &nbsp;
          <div style="color: var(--font-main-color); width: fit-content;"> <?php echo " " . $course; ?> </div>
        </div>
      </div>
    
    </div>
  </header>

  <main style="height: 90%; padding-bottom: 1rem">
    

  </main>
  <footer>

  </footer>
</body>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>

<script>
var temp_ass_array = json_encode($result_ass_comp, JSON_UNESCAPED_UNICODE );
var values = Object.keys(temp_ass_array).map(function(key){
    return temp_ass_array[key];
});
  
</script>



</html>