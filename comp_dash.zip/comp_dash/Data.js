/* GLOBAL VARIABLES */
var framework = Object.keys(framework_dict).map(function(key){
    return framework_dict[key];
});
var comp_course = Object.keys(comp_course_dict).map(function(key){
    return comp_course_dict[key];
});
var assignments_comp = Object.keys(ass_comp_dict).map(function(key){
    return ass_comp_dict[key];
});
var assignments = Object.keys(ass_dict).map(function(key){
    return ass_dict[key];
});
var students = Object.keys(students_dict).map(function(key){
    return students_dict[key];
});


var begin = true;
var chart1Data =[];
var chart1aDataComp =[];
var chart2b2_series0 =[];
var chart2b2_series1 =[];
var chart1aDataUser =[]; 
var chart1bData =[]; 
var studentNames = [];
var studentNames_ID = [];
var competencies = [];
var boxplotData =[];
var chart2b1_series0  = [];
var group1_data = [];
var group2_data =  [];
var group3_data = [];
var group4_data = [];

/* CALCULATE GROUPS */

function calculateGrowth(nameStudent, userID){
    var filterUser = assignments.filter(s => s.id == userID);

    // TOTAL GRADE
    const totalGrade = calculateGrade(filterUser);

    if(totalGrade != null) {
        // GRADE PERIODE 1
        // var filterPeriode1 = filterUser.filter(s => s.timemodifiedunix >= 1661990400 && s.timemodifiedunix < 1672531200 );
        var filterPeriode1 = filterUser.filter(s => (s.itemid == 4) ||(s.itemid == 5) || (s.itemid == 6)|| (s.itemid == 12) || (s.itemid == 8));
        const gradePer1 = calculateGrade(filterPeriode1);

        // GRADE PERIODE 2
        var today = Math.min(Math.floor(Date.now() / 1000) , 1688169599); // Max is end of school year
        // var filterPeriode2 = filterUser.filter(s => s.timemodifiedunix >= 1672531200 && s.timemodifiedunix < today);
        var filterPeriode2 = filterUser.filter(s =>(s.itemid == 9) ||(s.itemid == 10) || (s.itemid == 11)|| (s.itemid == 7) || (s.itemid == 13));
        const gradePer2 = calculateGrade(filterPeriode2);
        
        var x = totalGrade - 50;
        var y = gradePer2-gradePer1; // growth

        if ((x>=0 &&  y>=0) || (x>0 && x >= -y)) { // A1 & A2
            group1_data = group1_data.concat({name: nameStudent, value: 3, id: userID, custom: {growth: 'yes', grade: totalGrade}});
        } else if (x>0 && x < -y ) { // B
            group2_data = group2_data.concat({name: nameStudent, value: 3, id: userID, custom: {growth: 'no', grade: totalGrade}});
        } else if (x<0 && -x <= y) { // D
            group3_data = group3_data.concat({name: nameStudent, value: 3, id: userID, custom: {growth: 'yes', grade: totalGrade}});
        } else { // C1 & C2
            group4_data = group4_data.concat({name: nameStudent, value: 3, id: userID, custom: {growth: 'no', grade: totalGrade}});
        }
    }

}

function calculateGrade(filterUser) {
    var filterUsernotNULL = filterUser.filter(s => s.finalgrade != null)
  
    if (filterUsernotNULL.length == 0) {
        return null;
    } else {
        var finalgrade = filterUsernotNULL.map(a => a.finalgrade).map(Number).reduce(function(a, b){return a + b;});
        var max = filterUsernotNULL.map(a => a.rawgrademax).map(Number).reduce(function(a, b){return a + b;});
        var grade;
        if (max == 0) {
           grade = null;
        } else {
           grade = (finalgrade/max)*100;
        }
        return grade;
    }
  
}
/* CALCULATE NEW DATA */

function getCompData(compID, index, compName){
    // filter
    if (compID == 0) {
        var children = assignments_comp.filter(s => s.pathcomp === '/0/-1/');
    } else {
        var string = '/' + compID + '/';
        var children = assignments_comp.filter(s => s.pathcomp.includes(string));
    }
    
    var all_userid = [...new Set(children.map(a => a.id).map(Number))];
    var scatter = [];
    var boxplot = [];
    var heatmap = [];
    var studentNames_short = [];
    var student_names_id = [];
    var avg_comp = {};
    // Scatter + boxplot  (chart 1)
    all_userid.forEach((i, indexStudent) =>
      {var filter_id = children.filter(s => s.id == i); // specific user
      const unique = filter_id.filter(
        (obj, index) =>
        filter_id.findIndex((item) => item.itemid === obj.itemid) === index
      );
      const average = calculateGrade(unique);
     
      if(begin){
        calculateGrowth(filter_id[0].studentname, i)
      }
      
      if (average != null) {
        scatter = scatter.concat({x:index, y:+average.toFixed(2), name:filter_id[0].studentname, id:i});
        boxplot = boxplot.concat(+average.toFixed(2));
        heatmap = heatmap.concat({x:index, y:indexStudent, value:+average.toFixed(2), name:filter_id[0].studentname, id:i});
      }
      studentNames_short = studentNames_short.concat(filter_id[0].studentname.substring(0, filter_id[0].studentname.indexOf(" ")+2) + ".");
      student_names_id = student_names_id.concat(filter_id[0].id);
        
      }
    )

    studentNames = studentNames_short;
    if (begin) {
        studentNames_ID = student_names_id;
        begin = false;
    }
    // Number of assignments_comp (chart 2)
    var nb = [...new Set(children.map(a => a.itemid))].length;
    if (compID != 0) {compName = compName.substring(0, compName.indexOf("-")); }
    var nbAss = {y:nb, name:compName};
    
    return [scatter,boxplot, nbAss, heatmap];
    
}

function getAssData(compID, studentids) {
    var ass_filtered = assignments_comp.filter(s => s.competencyid == compID);
    var ass_name = [...new Set(ass_filtered.map(a => a.itemname))];
    let ass_index_dict = {};
    var ass_id = [...new Set(ass_filtered.map(a => a.itemid))];
    var values = Array.from(Array(10).keys());
    ass_id.forEach((key, i) => ass_index_dict[key] = values[i]);

    var scatter = [];
    var heatmap = [];
    var averg = [];
    var boxplot = new Array(ass_id.length);

    var children = assignments.filter(s => ass_id.indexOf(s.itemid) !== -1);
    for (let i = 0; i < children.length; i++) {
        var current_ass = children[i]
        if (current_ass.finalgrade == null) {
            continue;
        }
        var grade = (current_ass.finalgrade / current_ass.rawgrademax)*100
        var student_name = current_ass.studentname;
        var student_id = current_ass.id;
        scatter = scatter.concat({x: ass_index_dict[current_ass.itemid], y:+grade.toFixed(2), name: student_name, id: parseInt(current_ass.id)});
        heatmap = heatmap.concat({x:ass_index_dict[current_ass.itemid], y:studentids.indexOf(student_id), value:+grade.toFixed(2), name:student_name, id:parseInt(current_ass.id)});
    }

    for (let i = 0; i < ass_id.length; i++) {
      var itemid = ass_index_dict[ass_id[i]];
      var temp = scatter.filter(s => s.x == itemid);
      var val = temp.map(a => a.y).map(Number);
      boxplot[i] = val;
     
      const average = val.reduce((a, b) => a + b, 0) / val.length;
      averg = averg.concat({x:i, y: +average.toFixed(2), name:ass_name[i]}); //

    }
    
    return [scatter, boxplot, ass_name, heatmap, averg]
}

function setNewData(newPath, compID) {
    // given a path, what compID? e.g. path '/0/' -> [224, 0]
    var comp_dict = comp_course.filter(s => s.path == newPath);
    var scatterData = [];
    var heatmapData = [];
    var averg = [];
    
    if (comp_dict.length != 0 && compID != -1) { // show compentence
        var comp_id = comp_dict.map(a => a.id).map(Number);
        var yaxisnames = comp_dict.map(a => a.shortname);
        if(newPath === '/0/') { // show 'others' only on highest level
            comp_id = comp_id.concat(0);
            yaxisnames = yaxisnames.concat("Andere");
        }
       
        var exp = new Array(comp_id.length);
        var nbAssData = [];
        
        for (let i = 0; i < comp_id.length; i++) {
            result = getCompData(comp_id[i], i, yaxisnames[i]);
            scatterData = scatterData.concat(result[0]);
            exp[i] = result[1];
            nbAssData = nbAssData.concat(result[2]);
            heatmapData = heatmapData.concat(result[3]);
            // chart2
            if (comp_id[i] == 0) {
                var compName = yaxisnames[i]; 
            } else {
                var compName = yaxisnames[i].substring(0, yaxisnames[i].indexOf("-"));
            }
            const average = result[1].reduce((a, b) => a + b, 0) / result[1].length;
            averg = averg.concat({x:i, y: +average.toFixed(2), name:compName}); 
        }
       
    } else { // on deepest level: show assignments_comp
        var exp = [];
        result = getAssData(compID, studentNames_ID);
        scatterData = result[0];
        exp = result[1];
        var yaxisnames = result[2];
        heatmapData = result[3];
        averg = result[4];
    }


    
    competencies = yaxisnames;
    // CHART1
    chart1Data = scatterData;
    boxplotData = exp.map(getBoxPlotData);
    // CHART 1B (HEATMAP)
    chart1bData = heatmapData; 
    // CHART 1A (ronde BARCHART)
    chart1aDataComp = exp
    // CHART 2 
    chart2b1_series0 = nbAssData;
    chart2b2_series1 = averg
    chart2b2_series0 = new Array(chart1aDataComp.length);
    chart1aDataComp.forEach((arr, i) =>
      {
        const average = arr.reduce((a, b) => a + b, 0) / arr.length;
        chart1aDataComp[i] = +average.toFixed(2);
        if(isNaN(average)) {
            chart2b2_series0[i] = {x:i, y:100};
        } else {
            chart2b2_series0[i] = {x:i, y:+(100-average).toFixed(2)};
        }
      }
    )
   
}

/* SMALLER HELPER FUNCTIONS */

function setUserDataChart1a(userID) {
    if (userID == -1) {
        chart1a.series[1].setData([],true, true, false);
        chart1a.series[1].update({color: '#e9ecf4', name: 'No student selected'});
        document.getElementById("subtitleChart3").innerHTML = '';
    } else {
        chart1aDataUser = chart1Data.filter(s => s.id == userID).map(a => a.y).map(Number);
        chart1a.series[1].setData(chart1aDataUser,true, true, false);
        var studentName = students.filter(s => s.id == userID)[0].studentname
        document.getElementById("subtitleChart3").innerHTML = 'Geselecteerde student: ' + studentName;
        chart1a.series[1].update({color: selected_color_chart3, name: studentName});
    }
}

function getBoxPlotData(values) {
    var sorted = values.sort(function (a, b) {
        return a - b;
    });

    return {
        low: sorted[0],
        q1: sorted[Math.round(values.length * 0.25)],
        median: sorted[Math.round(values.length * 0.5)],
        q3: sorted[Math.round(values.length * 0.75)],
        high: sorted[sorted.length - 1]
    };
}

function makeButton(data, css, divID) {
    var cell4 = document.getElementById(divID);
    var student;

    for (let i = 0; i < data.length; i++) {
      
        student = data[i];

        var btnStudent = document.createElement("div");
        btnStudent.id = parseInt(student.id);
        btnStudent.innerHTML = student.name;
        btnStudent.className= css;
        btnStudent.onclick = function () {
            filterStudent(parseInt(this.id));
          };
        cell4.appendChild(btnStudent);
    }
}
/* START */
window.onload = () => {
    //modal
    const myModal = new bootstrap.Modal('#exampleModal');
    myModal.show();

    document.getElementById('gr1').innerHTML = group_name1;
    document.getElementById('gr2').innerHTML = group_name2;
    document.getElementById('gr3').innerHTML = group_name3;
    document.getElementById('gr4').innerHTML = group_name4;

    document.getElementById('gr1_nbStd').innerHTML = group1_data.length;
    document.getElementById('gr2_nbStd').innerHTML = group2_data.length;
    document.getElementById('gr3_nbStd').innerHTML = group3_data.length
    document.getElementById('gr4_nbStd').innerHTML = group4_data.length;

    document.getElementById("compLevel1").innerHTML = "sleutelcompetentie";
    document.getElementById("compLevel2").innerHTML = "Sleutelcompetenties";

    document.getElementById("modalLevel1").innerHTML = "sleutelcompetentie";
    document.getElementById("modalLevel2").innerHTML = "Sleutelcompetenties";
}

// data
setNewData('/0/', null, true);
// buttons growth
makeButton(group1_data, "btn btn-student1 btn-xs", "insertHere1");
makeButton(group2_data, "btn btn-student2 btn-xs", "insertHere2");
makeButton(group3_data, "btn btn-student3 btn-xs", "insertHere3");
makeButton(group4_data, "btn btn-student4 btn-xs", "insertHere4");