<?php
require_once("../../config.php");
global $DB;

$courseid = required_param('id', PARAM_INT);

$sql_ass_comp = "SELECT DISTINCT CONCAT(l.id,l.assid,COALESCE(r.competencyid, 0)) AS tempid, l.id as id,CONCAT(l.firstname, ' ', l.lastname) AS studentName, l.assid as itemid, l.itemname, CAST(l.finalgrade AS float) as finalgrade, CAST(l.rawgrademax AS float) as rawgrademax, l.courseid, COALESCE(r.path, '/0/') as path, COALESCE(r.competencyid, -1) AS competencyid, r.shortname, CONCAT(COALESCE(r.path, '/0/'),COALESCE(r.competencyid, -1), '/') AS pathComp
from 
(SELECT usr.firstname, usr.lastname,usr.id, gi.id as assid, gi.itemname, gg.finalgrade, gi.courseid, gg.rawgrademax
from mdl_grade_items as gi, mdl_grade_grades as gg, mdl_user as usr
WHERE gg.itemid = gi.id 
and usr.id = gg.userid 
and gi.itemtype = 'mod' 
and gi.courseid = ?) l
LEFT JOIN 
(SELECT distinct gi.id, gi.itemname, mc.competencyid, c.shortname, c.path
from mdl_competency_modulecomp as mc, 
mdl_course_modules as cm, 
mdl_grade_items as gi, 
mdl_competency as c,
mdl_grade_grades as gg
WHERE mc.cmid = cm.id 
and cm.instance = gi.iteminstance 
and mc.competencyid = c.id
and gg.itemid = gi.id
and gi.itemtype = 'mod') r on l.assid = r.id
ORDER BY  l.id, l.assid";

$sql_ass = "SELECT  CONCAT(usr.id,gi.id) AS tempid, usr.id, CONCAT(usr.firstname, ' ', usr.lastname) AS studentName, gi.id as itemID, gi.itemname, CAST(gg.finalgrade AS float) as finalgrade, CAST(gg.rawgrademax AS float) as rawgrademax, gi.courseid, gi.timemodified as timemodifiedUnix 
from mdl_grade_items as gi, mdl_grade_grades as gg, mdl_user as usr
WHERE gg.itemid = gi.id 
and usr.id = gg.userid 
and gi.itemtype = 'mod' 
and gi.courseid = ?
ORDER BY usr.firstname";

$sql_course = "SELECT fullname
              FROM mdl_course as c
              where c.id = ?";
$sql_framework = "SELECT id as frameworkID, shortname as frameworkNAME
from mdl_competency_framework";

$sql_comp_course = "SELECT distinct p.id, shortname, parentid, path, competencyframeworkid
from mdl_competency as p
where exists (select 1 from mdl_competency_coursecomp as cc, mdl_competency as c
WHERE cc.competencyid = c.id and cc.courseid = ?
and path like concat('%/', p.id,'/%'))
UNION
SELECT cc.competencyid, shortname, parentid, path, competencyframeworkid
from mdl_competency_coursecomp as cc, mdl_competency as c
WHERE cc.competencyid = c.id and cc.courseid = ?";

$sql_students ="SELECT
ROW_NUMBER() OVER (ORDER BY u.lastname ASC) AS No, 
u.id,
CONCAT(u.firstname, ' ', u.lastname) AS studentName
FROM
mdl_role_assignments ra
JOIN mdl_user u ON u.id = ra.userid
JOIN mdl_role r ON r.id = ra.roleid
JOIN mdl_context cxt ON cxt.id = ra.contextid
JOIN mdl_course c ON c.id = cxt.instanceid
WHERE ra.userid = u.id
AND ra.contextid = cxt.id
AND cxt.contextlevel =50
AND cxt.instanceid = c.id
AND  roleid = 5
and c.id = ?
ORDER BY u.lastname";

$result_ass_comp = $DB->get_records_sql($sql_ass_comp, array($courseid));
$result_ass = $DB->get_records_sql($sql_ass, array($courseid));
$result_course = $DB->get_records_sql($sql_course, array($courseid));

$result_framework = $DB->get_records_sql($sql_framework);
$result_comp_course = $DB->get_records_sql($sql_comp_course, array($courseid, $courseid));
$result_students = $DB->get_records_sql($sql_students, array($courseid));

$course = array_column($result_course, 'fullname')[0];

 
?>




<!DOCTYPE html>
<html lang="nl">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
  
  <script src="https://code.highcharts.com/10.3.3/highcharts.js"></script>
  <script src="https://code.highcharts.com/10.3.3/highcharts-more.js"></script>
  <script src="https://code.highcharts.com/10.3.3/modules/heatmap.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" rel="stylesheet">

  <link rel="stylesheet" href="./styleDashboard.css">

  <title>Moodle - Competentie dashboard</title>

</head>

<!-- Google tag (gtag.js) -->
<!-- <script async src="https://www.googletagmanager.com/gtag/js?id=G-V2XTM4YQSN"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-V2XTM4YQSN');
</script> -->

<body style="height: 100vh; max-height:100vh;">
  <header style="height: 10%">
    <div class="row" style="height: 100%">
      <div class="col w-50" style="height: 100%">
        <div class="logo td" style="height: 100%;">
          <span style="height: 100%;">Competentie dashboard&nbsp;</span>
          
          
          <span class="td courseText" style="color: rgb(11, 35, 97, 0.6); height: 100%;">&nbsp;<?php echo " " . $course; ?></span>
          <button type="button" class="btn btn-link " data-bs-toggle="modal" data-bs-target="#exampleModal"><span class="bi bi-info-circle" style="font-size:25px;color:rgb(11, 35, 97, 0.6)"></span></button>               
        </div>
      </div>
      <div class="col w-50 hbreadcrumb d-flex justify-content-center" style="padding-right: 0;padding-left: 0;">
        <span class="align-self-end" >  
          <button id="breadcrumb0" type="button" class="btn btn-link btn-breadcrumb btn-currentLevel" onclick="breadcrumbLevel(0)" style="padding-bottom: 9px;">Sleutelcompetenties</button> <i id="breadcrumbicon1" class="bi bi-caret-right-fill arrowbreadcrumb d-inline-flex align-items-center" style="color: #959CA4"></i> <button id="breadcrumb1" type="button" class="btn btn-link btn-breadcrumb" onclick="breadcrumbLevel(1)"  style="padding-bottom: 9px;" disabled>Bouwstenen</button> <i id="breadcrumbicon2" class="bi bi-caret-right-fill arrowbreadcrumb d-inline-flex align-items-center" style="color: #959CA4"></i> <button id="breadcrumb2" type="button" class="btn btn-link btn-breadcrumb" onclick="breadcrumbLevel(2)"  style="padding-bottom: 9px;" disabled>Eindtermen</button> <i  id="breadcrumbicon3" class="bi bi-caret-right-fill arrowbreadcrumb d-inline-flex align-items-center" style="color: #959CA4"></i> <button id="breadcrumb3" type="button" class="btn btn-link btn-breadcrumb" onclick="breadcrumbLevel(3)"  style="padding-bottom: 9px;" disabled>Toetsen/taken</button>
        </span>
      </div>
    </div>
  </header>

  <main style="height: 90%; padding-bottom: 1rem">
      <div class="" style="height: 100%;">
          <div class="col"style="height: 100%;max-height: 100%;">
                <div class="row" style="height: 100%;max-height: 100%;">
                  
                  <div class="col w-50" style="height: 100%;max-height: 100%; padding-left: 0;">
                      <div class="row whiteb w-100 h-50 d-inline-block" >

                              <div class="row" style="height:15%;" >
                                <div class="col" > </div>
                              
                                <div class="col-7">
                                  <div class="h4 mb-0">Leerlingen</div>
                                  <div class="hsub"><span id="subtitleChart3"></span></div>
                                </div>

                                <div class="col btn-group-right">

                                  <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                    <input type="radio" class="btn-check" name="btnradioCH3" id="btnradio4" onchange="showGrowth()" autocomplete="off" checked>
                                    <label class="btn btn-outline-primary" for="btnradio4"> A</label>
                                  
                                    <input type="radio" class="btn-check" name="btnradioCH3" id="btnradio5"  onchange="showGrowth()"autocomplete="off">
                                    <label class="btn btn-outline-primary" for="btnradio5"> B</label>
                                  
                                   
                                  </div>
                                </div>
                              </div>

            
                        
                                <div class="row d-inline-block" style="height:75%;" >
                                  <div id="container3" style="display: none; "></div>
                                  <div id="insertHere"class="row" style="height:100%;overflow: auto;">
                                    <div id="insertHere1"  class="col" >
                                      <div class="h5 gr1"><p id="gr1" class="mb-0"></p></div>
                                      <div class="hsub mb-1"><i class="bi bi-person-fill"></i> <span id="gr1_nbStd"></span> </div>
                                    </div>
                                    <div id="insertHere2" class="col">
                                      <div class="h5 gr2"><p id="gr2" class="mb-0"></p></div>
                                      <div class="hsub mb-1"><i class="bi bi-person-fill"></i> <span id="gr2_nbStd"></span> </div>
                                    </div>
                                    <div id="insertHere3" class="col">
                                      <div class="h5 gr3"><p id="gr3" class="mb-0"></p></div>
                                      <div class="hsub mb-1"><i class="bi bi-person-fill"></i> <span id="gr3_nbStd"></span> </div>
                                    </div>
                                    <div id="insertHere4" class="col">
                                      <div class="h5 gr4"><p id="gr4" class="mb-0"></p></div>
                                      <div class="hsub mb-1"><i class="bi bi-person-fill"></i> <span id="gr4_nbStd"></span> </div>
                                    </div>
                                  </div>
                                </div>

                                <div class="row" style="height:10%;" > 
                                  <button type="button" class="btn btn-link h6 d-flex justify-content-end" data-bs-toggle="modal" data-bs-target="#modalCHART3">Info?</button>
                              </div>
                      </div>
                    
                      <div class="row" style="height: 1.5%;">  </div>

                      <div class="row whiteb w-100 d-inline-block" style="height: 48.5%;">
                        <div class="row" style="height:18.5%; ">
                          <div class="col"> </div>
                          <div class="col-6">
                            <div class="h4 mb-0" style="padding-bottom: 1px;"><span id="compLevel2"></span></div>
                            <div class="hsub mb-0" style="font-size: 11px; line-height: 1.1;"><span id="subtitleChart2"></span></div>
                          </div>
                          <div class="col">
                          </div>
                        </div>

                        <div class="row" style="height:74%; " >
                          <div style="width: 40%; padding: 0;" id="container2b1"></div>
                          <div style="width: 60%;padding: 0;" id="container2b2"></div>
                      </div>

             
                        

                        <div class="row" style="height:7.5%;" >
                          <div class="col-9" style="height:100%;"> 
                            <div class="row hlegende" style="height:100%;">
                              <div id="legchart2b1" class="col center-block" style="text-align:right;"><i class="bi bi-circle-fill" style="color: rgb(126, 183, 238, 0.75);"></i> Aantal toetsen/taken &nbsp &nbsp</div>
                              <div id="legchart2b2" class="col center-block" style="text-align:center;"><i class="bi bi-circle-fill" style="color: rgb(11, 35, 97, 0.7);"></i> Klas gemiddelde </div>
                              
                            </div>
                          </div>
                          <div class="col d-flex justify-content-end" style="height:100%; padding:0" > 
                            <button type="button" class="btn btn-link h6" style="height:100%; padding-top: 0;" data-bs-toggle="modal" data-bs-target="#modalCHART2">Info?</button>
                          </div>
                       </div>
                      </div>
                    </div>
                    

                    <div class="col whiteb w-50" style="height: 100%;max-height: 100%;position: relative;">
                      <div class="row" style="height:11.5%;" >
                        <div class="col"> <button type="button" class="btn btn-labeled btn-default" id="buttonChart1" style="display: none; color:#5b5b5d;" onclick="levelBack();filterCompetency(parentCompID)"> <span class="btn-label"><i class="fa fa-chevron-left" style="font-size:13px;color:rgb(11, 35, 97, 0.6)"></i></span>  Terug</button> </div>
                        <div class="col-7">
                          <div class="h4 mb-0">Resultaten leerlingen per <span id="compLevel1"></span></div>
                          <div class="hsub"><span id="subtitleChart1"></span></div>
                          
                        </div>
                        <div class="col btn-group-right">
                          <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                            <input type="radio" class="btn-check" name="btnradio" id="btnradio1" onchange="showCHART1(1)" autocomplete="off" checked>
                            <label class="btn btn-outline-primary" for="btnradio1"> A</label>
                          
                            <input type="radio" class="btn-check" name="btnradio" id="btnradio2"  onchange="showCHART1(2)" autocomplete="off" >
                            <label class="btn btn-outline-primary" for="btnradio2"> B</label>
                          
                            <input type="radio" class="btn-check" name="btnradio" id="btnradio3" onchange="showCHART1(3)" autocomplete="off">
                            <label class="btn btn-outline-primary" for="btnradio3"> C</label>
                          </div>
                        </div>
                      </div>
                      

                      <div class="row" style="height:84.5%;" > 
                        <div  id="container"></div>
                        <div style="display: none" id="container1a"></div>
                        <div  style="display: none" id="container1b"></div>
                      </div>
                      <div class="row" style="height:4%;" > 
                        <div class="col w-50"> 
                          <div id="boxplot" class="form-check form-switch ">
                            <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault" onchange="showBoxplot()" checked>  
                            <label class="form-check-label" for="flexSwitchCheckDefault">Show boxplot</label>
                          </div> 
                        </div>
                        <div class="col d-flex justify-content-end w-50"> 
                          <button type="button" class="btn btn-link h6 " data-bs-toggle="modal" data-bs-target="#modalCHART1" style="padding-right: 0;">Info?</button>
                        </div>
                    </div>
              </div>

                </div>


           
          </div>

        


      </div>
      <!-- Modal start-->
      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><span class="bi bi-info-circle" style="font-size:20px;"></span> Welkom op het competentie dashboard!</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              Dit dashboard visualiseert data over uw leerlingen en hun competenties. 
              Volgende vragen kunnen allemaal beantwoord worden met de grafieken van het dashboard:<br>
              <ul>
                <li>"Hoe ver is een leerling gevorderd op een bepaalde competentie?"</li>
                <li>"Op welke competenties kunnen leerlingen extra oefenen?"</li>
                <li>"Bij welke leerlingen is er een groei of daling in de punten?"</li>
                <li>"Waar moet de klas nog meer op oefenen?"</li>
                <li>"Welke leerlingen lopen achter?"</li>
              </ul>
              
              
              Heeft u moeilijkheden met de interpretatie van sommige grafieken? Klik dan zeker op de knop "Info?" onder de grafiek of kijk de tutorial video hier.
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sluit</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal "meer uitleg"-->
      <div class="modal fade" id="modalCHART1" tabindex="-1" aria-labelledby="modalCHART1Label" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modalCHART1Label">Meer uitleg over het onderdeel "Resultaten leerlingen per <span id="modalLevel1"></span>"</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <h6> Welke informatie kan ik terugvinden?</h6> 
              In deze sectie kan u vragen beantwoorden zoals:
              
              <ul>
                <li>"Hoe ver is een leerling gevorderd op een bepaalde competentie?"</li>
                <li>"Wat is de prestatie van de hele klas op een bepaalde competentie?"</li>
                <li> "Op welke competenties kunnen leerling(en) extra oefenen?"</li>
              </ul>
    
              
              <h6>Wat zijn de verschillende opties? </h6> 
              In de rechter bovenhoek kan u kiezen uit drie opties: A, B of C.

              <ul>
                <li><span class="color5 hbold">Optie A</span>: Deze grafiek geeft een algemeen beeld over uw klas en de distributie van de resultaten. Elke stip staat voor een leerling uit uw klas.</li>
                <li><span class="color5 hbold">Optie B</span>: Deze grafiek geeft een eenvoudiger overzicht, waarbij u een specifieke leerling kan vergelijken met het klas gemiddelde.</li>
                <li><span class="color5 hbold">Optie C</span>: Deze tabel geeft een overzicht van alle resultaten (in procent) per leerling. Hoe donkerder de kleur, des te lager het resultaat van de leerling is.</li>
              </ul>
              
              <h6>Hoe ga ik naar een lager competentie niveau?</h6> 
              U kunt een niveau dieper gaan door op de naam van de competentie te klikken. Om u te helpen navigeren waar u zich bevindt in de hiërarchie, staat bovenaan een navigatiestructuur.

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sluit</button>
            </div>
          </div>
        </div>
      </div>


          <!-- Modal "meer uitleg"-->
          <div class="modal fade" id="modalCHART2" tabindex="-1" aria-labelledby="modalCHART2Label" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="modalCHART2Label">Meer uitleg over het onderdeel "<span id="modalLevel2"></span>"</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <h6> Welke informatie kan ik terugvinden?</h6> 
                    U vindt hier het aantal toetsen/taken terug die u afgenomen heeft per competentie, met telkens daarnaast het klasgemiddelde.
                    In deze sectie kan u vragen beantwoorden zoals:
                    
                    <ul>
                      <li>"Hoeveel tijd heb ik (in deze cursus) besteed aan een bepaalde competentie?"</li>
                      <li>"Zie ik een rendement van mijn tijd in competenties waar ik meer aandacht aan heb besteed?"</li>
                    </ul>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sluit</button>
                </div>
              </div>
            </div>
          </div>

      <!-- Modal "meer uitleg"-->
      <div class="modal fade" id="modalCHART3" tabindex="-1" aria-labelledby="modalCHART3Label" aria-hidden="true">
        <div class="modal-dialog  modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="modalCHART3Label">Meer uitleg over het onderdeel "Leerlingen"</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <h6> Welke informatie kan ik terugvinden?</h6> 
              In deze sectie kan u vragen beantwoorden zoals:
              
              <ul>
                <li>"Bij welke leerlingen is er een groei of daling in de punten?"</li>
                <li>"Welke leerlingen lopen achter?"</li>
              </ul>
    
              <h6>Hoe moet ik de vier groepen interpreteren?</h6> 
              De klas wordt opgedeeld in vier groepen. Eerst splitsen we de klas in een groep die geslaagd (boven 50%) is voor uw vak en een groep die een tekort (onder 50%) heeft op uw vak. Hierna kijken we naar groei in punten:
              zien we een daling of stijging in de punten?

              <ul>
                <li><span class="gr1 hbold">GESLAAGD</span>: de leerling is geslaagd en alles is oké!</li>
                <li><span class="gr2 hbold">GESLAAGD/DALING</span>: de leerling is geslaagd, maar pas op! We zien een daling in de punten.</li>
                <li><span class="gr3 hbold">TEKORT/GROEI</span>: de leerling heeft een tekort, maar we zien een stijging in de punten. Dus ga zo door!</li>
                <li><span class="gr4 hbold">TEKORT</span>: de leerling heeft een tekort en we zien geen vooruitzicht op verbetering.</li>
              </ul>

              <h6>Wat zijn de verschillende opties? </h6> 
              In de rechter bovenhoek kan u kiezen uit twee opties: A of B.

              <ul>
                <li><span class="color5 hbold">Optie A</span>: Hier ziet u alle leerlingen (per groep) opgelijst onder elkaar. Scroll naar beneden voor alle leerlingen te bekijken.</li>
                <li><span class="color5 hbold">Optie B</span>: Deze grafiek geeft een overzicht van uw klas en kan u een inschatting maken hoe groot elke groep is.</li>
              </ul>
              
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Sluit</button>
            </div>
          </div>
        </div>
      </div>

  </main>
  <footer>

  </footer>
 
</body>


<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
<script>
  console.log("test");
  var comp_course_dict =  <?php echo json_encode($result_comp_course, JSON_UNESCAPED_SLASHES); ?>;
  var framework_dict = <?php echo json_encode($result_framework, JSON_UNESCAPED_UNICODE );?>;
  var ass_comp_dict = <?php echo json_encode($result_ass_comp, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);?>;
  var ass_dict = <?php echo json_encode($result_ass, JSON_UNESCAPED_UNICODE );?>;
  var students_dict = <?php echo json_encode($result_students, JSON_UNESCAPED_UNICODE);?>;
  console.log(comp_course_dict);
  console.log(framework_dict);
  console.log(ass_comp_dict);
  console.log(ass_dict);
  console.log(students_dict);
</script>
<script src="Data.js"></script>
<script src="Filter.js"></script>
<script src="charts/chart1.js"></script>
<script src="charts/chart1a.js"></script>
<script src="charts/chart1b.js"></script>
<script src="charts/chart2b1.js"></script>
<script src="charts/chart2b2.js"></script>
<script src="charts/chart3.js"></script>


</html>