<?php

class block_comp_dash extends block_base {
   

    function init() {
        $this->title = get_string('pluginname', 'block_comp_dash');
    }


    function get_content() {
        global $DB;
        global $CFG;


        $course = $this->page->course;

        if ($this->content !== NULL) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this->content->text = "";

        $this->content->text .= "<button id='myButton' type='button' class='btn btn-primary' style='width:100%; margin-bottom:1em'> Go to competency dashboard! </button>";
        $this->content->text .= "<script type='text/javascript'> document.getElementById('myButton').onclick = function () {window.open('{$CFG->wwwroot}/blocks/comp_dash/competence_dash.php?id={$course->id}', '_blank'); };</script>";

        $this->content->footer = '<hr/>';

        return $this->content;
    }

}
