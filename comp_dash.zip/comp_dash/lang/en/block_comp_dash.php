<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_comp_dash', language 'en', branch 'MOODLE_20_STABLE'
 *
 * @package   block_comp_dash
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


$string['comp_dash:addinstance'] = 'Add a new competence block';
$string['comp_dash:myaddinstance'] = 'Add a new competence block to Dashboard';
$string['comp_dash'] = 'TeachWiseX';
// $string['pluginname'] = 'TeachWise: een competentie dashboard';
$string['pluginname'] = 'Competency dashboard';

