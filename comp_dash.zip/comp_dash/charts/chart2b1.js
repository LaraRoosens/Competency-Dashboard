const chart2b1 = Highcharts.chart('container2b1', {

    chart: {
        type: 'bar'
    },

    title: {
        text: undefined
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true
            }
        }
    },

    xAxis: {
        type: 'category',
        labels: {
            enabled: true,
            align: 'center'
        }
    },

    yAxis: {
        title: {
            text: undefined
        },
        allowDecimals: false,
        labels: {
            enabled: false
        },
        gridLineColor: 'transparent',
    },
    credits: {
        enabled: false
    },
     exporting: {
        enabled: false
    },

    series: [{
        dataLabels: [{
            align: 'left',
            format: '{point.y}',
            color: 'rgb(11, 35, 97)'
        }],
        name: 'Aantal toetsen/taken',
        data: chart2b1_series0,
        showInLegend: false,
        color: 'rgb(126, 183, 238, 0.75)'
    }]

});

