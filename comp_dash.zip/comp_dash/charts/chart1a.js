const chart1a = Highcharts.chart('container1a', {
    colors: ['rgb(11, 35, 97, 0.65)', '#e9ecf4'],
    chart: {
        type: 'column',
        inverted: true,
        polar: true,
        events: {
            load() {
              let chart = this;
              clickLabel(chart);
            }
          } 
        
    },
    title: {
        text: undefined
    },
    tooltip: {
        outside: true
    },
    credits: {
        enabled: false
    },
    exporting: {
      enabled: false
    },
    pane: {
        size: '85%',
        innerSize: '20%',
        endAngle: 270
    },
    xAxis: {
        tickInterval: 1,
        labels: {
            align: 'right',
            useHTML: true,
            allowOverlap: true,
            step: 1,
            y: 3,
            style: {
                fontSize: '13px'
            }
        },
        lineWidth: 0,
        categories: competencies,
        labels: {
            events: {
              click: function() {
                console.log('test')
              }
            }
          }
    },
    yAxis: {
        crosshair: {
            enabled: true,
            color: '#333'
        },
        lineWidth: 0,
        tickInterval: 25,
        reversedStacks: false,
        endOnTick: true,
        showLastLabel: true,
        max: 100,
        min:0,
         plotLines: [{
            color: '#f1554c',
            width: 2,
            value: 50
        }]
    },
    plotOptions: {
        column: {
            borderWidth: 0,
            pointPadding: 0,
            groupPadding: 0.15
        }
    },
    series: [{
        name: 'Klas gemiddelde',
        data: chart1aDataComp,
        tooltip: {
            useHTML: true,
            pointFormat: '<b>Klas gemiddelde</b><br>Resultaat: {point.y}%'
        }
    }, {
        name: 'Geen student geselecteerd', //No student selected
        data: chart1aDataUser,
        tooltip: {
            useHTML: true,
            pointFormat: '<b>{point.series.name}</b><br>Resultaat: {point.y}%'
        }
    }]
});

