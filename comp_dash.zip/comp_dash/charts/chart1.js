const chart1 = Highcharts.chart('container', {

    title: {
        text: undefined
    },
    credits: {
        enabled: false
    },
    exporting: {
        enabled: false
      },
    legend: {
        enabled: false
    },
    chart: {
        inverted: true,
        events: {
            load() {
              let chart = this;
              clickLabel(chart);
            }
          }   
    },

    xAxis: {
        categories: competencies,
       
    },

    yAxis: {
        title: {
            text: 'Resultaten (%)'
        },
         max: 100,
         min:0,
         plotLines: [{
            color: '#f1554c',
            width: 1,
            value: 49.99,
            dashStyle: 'dash'
        }]
    },
    
      plotOptions: {
      
        series: {
            point: {
                events: {
                    click: function() {
                        filterStudent(this.id);
                        
                    }
                }
            }
        }
    },
    
    

    series: [{
        type: 'boxplot',
        name: 'Boxplot',
        data: boxplotData,
         color: 'rgba(100, 100, 100, 0.5)'
    }, {
        name: 'Studenten',
        type: 'scatter',
        data: chart1Data,
        jitter: {
            x: 0.24 // Exact fit for box plot's groupPadding and pointPadding
        },
        marker: {
            radius: 4
        },
        color: 'rgb(11, 35, 97, 0.65)',
        tooltip: {
            useHTML: true,
            pointFormat: '<b>{point.name}</b><br>Resultaat: {point.y}%'
        }
        
    }]
});