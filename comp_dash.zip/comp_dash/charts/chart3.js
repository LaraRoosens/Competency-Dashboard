var group_name1 ='GESLAAGD ';
var group_name2 ='GESLAAGD/DALING ';
var group_name3 ='TEKORT/GROEI ';
var group_name4 ='TEKORT ';


const chart3 = Highcharts.chart('container3', {
  chart: {
    type: 'packedbubble',
  },
   credits: {
    enabled: false
  },
  exporting: {
    enabled: false
  },
  title: {
    text: undefined
  },
    legend: {
      enabled:true,
    	layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
        itemMarginTop: 0,
        itemMarginBottom: 10,
        useHTML: true,
        margin: 0,
        labelFormatter: function() {
            if (this.name == group_name1){
                return this.name + "<img src='./images/check-circle.svg' style='width:18px;height:15px;display: inline-block;height: 100%;vertical-align: middle;'>"
            }  else if (this.name == group_name2) {
               return this.name + "<img src='./images/exclamation-triangle.svg' style='width:18px;height:15px;display: inline-block;height: 100%;vertical-align: middle;'>"
            }  else if (this.name == group_name3) {
                return this.name + "<img src='./images/hand-thumbs-up.svg' style='width:18px;height:15px;display: inline-block;height: 100%;vertical-align: middle;'>"
            } else {
                return this.name + "<img src='./images/x-circle.svg' style='width:18px;height:15px;display: inline-block;height: 100%;vertical-align: middle;'>"
            }
        }
   },
  tooltip: {
    useHTML: true,
    pointFormat: '<b>{point.name}</b> <br> Resultaat test: {point.custom.grade}%'
  }, 
  plotOptions: {
    packedbubble: {
      minSize: '20%',
      maxSize: '100%',
      zMin: 0,
      zMax: 100,
      layoutAlgorithm: {
        gravitationalConstant: 0.02,
        splitSeries: true,
        seriesInteraction: false,
        dragBetweenSeries: true,
        parentNodeLimit: true,
        enableSimulation: false
      },
      dataLabels: {
        enabled: true,
        format: '{point.name}',
        filter: {
          property: 'y',
          operator: '>',
          value: 5
        },
        style: {
          color: 'black',
          textOutline: 'none',
          fontWeight: 'normal'
        }
      }
    },
     series: {
            point: {
                events: {
                    click: function() {
                        selected_group_chart3 = this.series.name;
                        selected_color_chart3 = this.series.color.replace(", 0.3)", ")");;
                        filterStudent(this.id);
                    }
                }
            }
        }
    
    
    
  }  ,  series: [{
        name:  group_name1,
        color: 'rgb(25, 176, 45, 0.3)',
        marker: {
                fillColor: 'rgb(25, 176, 45, 0.9)',
                lineWidth: 2,
                lineColor: 'rgb(25, 176, 45)' // null= inherit from series
            },
        data: group1_data
    }, {
        name: group_name2,
        color: 'rgb(156, 208, 19, 0.3)',
        marker: {
                fillColor: 'rgb(156, 208, 19, 0.9)',
                lineWidth: 2,
                lineColor: 'rgb(156, 208, 19)'
            },
        
        data: group2_data
    }, {
        name: group_name3,
        color: 'rgb(239, 145, 161, 0.3)',
        marker: {
                fillColor: 'rgb(239, 145, 161, 0.9)',
                lineWidth: 2,
                lineColor: 'rgb(239, 145, 161)' 
            },
        data: group3_data
    },{
        name: group_name4,
        color: 'rgb(241, 85, 76, 0.3)',
        marker: {
                fillColor: 'rgb(241, 85, 76, 0.9)',
                lineWidth: 2,
                lineColor: 'rgb(241, 85, 76)' 
            },
        data: group4_data
    }]
});