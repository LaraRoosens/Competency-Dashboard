const chart2b2 = Highcharts.chart('container2b2', {

    chart: {
        type: 'bar'
    },

    title: {
        text: undefined
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true
            }
        }
    },

    xAxis: {
        type: 'category',
         
        labels: {
            enabled: false,

        }
    },

    yAxis: {
        title: {
            text: undefined
        },
        allowDecimals: false,
        max: 100,
         min:0,
         labels: {
            enabled: false,

        },
        gridLineColor: 'transparent',
        
        plotLines: [{
            color: '#f1554c',
            width: 1,
            value: 49.99,
            dashStyle: 'dash'
        }]
    },
    credits: {
        enabled: false
    },
     exporting: {
        enabled: false
    },
    plotOptions: {
        bar: {
            stacking: 'percent',
            dataLabels: {
                enabled: true
            }
        }
    },
    series: [{
        data: chart2b2_series0,
        data: [
            38.93,
            38,
        ],
        showInLegend: false,
        enableMouseTracking: false,
        dataLabels: [{
            enabled: false
        }],
        color: 'rgb(233, 236, 244, 0.75)'
    },{
        dataLabels: [{
            align: 'right',
            format: '{point.y}%',
            color: 'white'
        }],
        name: 'Klas gemiddelde',
        data: chart2b2_series1,
        showInLegend: false,
        color: 'rgb(11, 35, 97, 0.65)'
    }]

});

