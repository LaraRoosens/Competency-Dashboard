function getPointCategoryName(point, dimension) {
    var series = point.series,
        isY = dimension === 'y',
        axis = series[isY ? 'yAxis' : 'xAxis'];
    return axis.categories[point[isY ? 'y' : 'x']];
}

const chart1b = Highcharts.chart('container1b', {

    chart: {
        type: 'heatmap',
        plotBorderWidth: 1,
        events: {
            load() {
              let chart = this;
              clickLabel(chart);
            }
          } 
    },


    title: {
        text: undefined
    },
		 credits: {
        enabled: false
    },
    exporting: {
      enabled: false
    },
    xAxis: {
    		
        opposite: true,
        categories: competencies,
        labels: {
            formatter: function () {
                if (competencies.length > 3) {
                    return '<a>' +this.value.split('-')[0] + '</a>';
                }
                return '<a>' +this.value + '</a>';
            }
        }
    },

    yAxis: {
        categories: studentNames,
        title: null,
        reversed: true,
        labels: {
            events: {
            click: function() {
                alert('hey!!!!!!!!!!')
            }
            }
        }
    },

  

    colorAxis: {
        min: 0,
        stops: [
            [0, 'rgb(11, 35, 97)'], //blue
            [0.51, '#FFFFFF'], //white
            [1, '#FFFFFF'] //white
        ]
    },

    legend: {
        align: 'right',
        layout: 'vertical',
        margin: 0,
        verticalAlign: 'top',
        y: 165,
        symbolHeight: 140,
        enabled: false
    },

    tooltip: {
        formatter: function () {
            return '<b>' + getPointCategoryName(this.point, 'y') + '</b> heeft <br><b>' +
                this.point.value + '</b> % behaald op <br><b>' + getPointCategoryName(this.point, 'x') + '</b>';
        }
    },

    series: [{
        name: 'Resultaten',
        data: chart1bData,
        borderWidth: 1, // 0 to get rid of it altogether
        borderColor: '#e9ecf4',
        dataLabels: {
            enabled: true,
            color: '#000000'
        }
    }],


});