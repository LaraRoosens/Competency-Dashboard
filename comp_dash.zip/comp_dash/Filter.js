
/* GLOBAL VARIABLES */
let previousPoint;
let previousPoint2;
let selected_userID;
let selected_group_chart3;
let selected_color_chart3;
let parentCompID;
let currentLevelComp = 0;
let others = false;

/* HANDLE CLICK/FILTER STUDENT */
    
// Chart 1: change when student is selected
function handleClick1(point,chart){
  
  if(point.series.data == chart.series[1].data) {// Only scatter points (not boxplot)
   if(previousPoint){// If we have a previous point, reset its color
        let oldpointID = previousPoint.id;
        for (let i = 0; i < point.series.data.length; i++) {
          if (point.series.data[i].id == oldpointID) {
          	
            point.series.data[i].update({color: previousPoint.originalColor, marker: {radius: 4}});
          }
        }
      }
    // Highlight points of student
    let pointID = point.id;
    if(previousPoint && (point.id==previousPoint.id)){
      // clear all
      let temp;
      previousPoint = temp;
    } else {
    	for (let i = 0; i < point.series.data.length; i++) {
        if (point.series.data[i].id == pointID) {
          point.series.data[i].update({color: selected_color_chart3, originalColor: point.color, marker: {radius: 10}});
        }
      }
      previousPoint = point;
    }

    

  }  
      
}

// Chart 3: change when student is selected
function handleClick3(point){
if(previousPoint2){
       previousPoint2.update({color: previousPoint2.originalColor, value: 3});
 }
 if(previousPoint2 && (point.id==previousPoint2.id)){
   // clear all
   let temp;
   previousPoint2 = temp;
 } else {
   point.update({value: 40});
   previousPoint2 = point;
 }
}

  

function filterStudent(pointID=null)
{  
    if (isNaN(pointID)) return; // check if pointID is number, if not a number then stop
    var userID = pointID
    // Buttons highlight when clicked on (section "Leerlingen")
    var selected_element = document.getElementById(userID.toString());
    selected_element.classList.add("btn-click");
    if(selected_userID) {
      var deselected_element = document.getElementById(selected_userID.toString());
      deselected_element.classList.remove("btn-click");
    }
   
    selected_userID = userID
    // CHART3
    var group_chart3;
    var index_chart3;
      // find point by finding in what group userID is and what index
    let allgroups = [group1_data, group2_data, group3_data, group4_data];
    for (var i = 0; i < allgroups.length; i++) {
        index_chart3 = allgroups[i].map(function(e) { return e.id; }).indexOf(userID);
        if(index_chart3 != -1){
            group_chart3 = i
            break
        }
    }
    handleClick3(chart3.series[group_chart3].data[index_chart3]);
    let colorGroups = {0:'rgb(25, 176, 45)' ,1:'rgb(156, 208, 19)',2:'rgb(239, 145, 161)',3:'rgb(241, 85, 76)'};
    selected_color_chart3 = colorGroups[group_chart3];
    
    // CHART 1
    var index = chart1Data.map(function(e) { return e.id; }).indexOf(userID);

    if (index != -1){
	  handleClick1(chart1.series[1].data[index], chart1);

    
    // CHART1A & CHART1B
    if(previousPoint && (pointID==previousPoint.id)){ // select student
      // CHART1A
      setUserDataChart1a(userID); 
      // CHART1b
      var user = chart1bData.filter(s => s.id == userID); // specific user
      var index = user[0].y;
      var from = index - 0.5;
      chart1b.update({ yAxis: {
          plotBands: [{
            borderWidth: 4,
            borderColor: selected_color_chart3,
            color: 'transparent',
            from: from,
            to: from+1,
            zIndex: 20
          }] }  });
    } else {// deselect student
       // CHART1A
      setUserDataChart1a(-1); 
       // CHART1b
       var user = chart1bData.filter(s => s.id == userID); // specific user
       var index = user[0].y;
       var from = index - 0.5;
       chart1b.update({ yAxis: {
           plotBands: [] }  });

    }  
  }
}

/* HANDLE CLICK/FILTER COMPETENCY */
function filterCompetency(compID){
  
  var competencyID = compID
  var button = document.getElementById("buttonChart1");  //  Back button

  let temp;
  parentCompID = temp;
  // Set new data
  if (competencyID == 0){
    setNewData('/0/', null);
    button.style.display = "none"; // highest level no back button
  } else {
    var filter_path;
    if (compID != -1) {
      filter_path = comp_course_dict[competencyID].path + competencyID + '/';
      parentCompID = comp_course_dict[competencyID].parentid;
    } else { // comID == 1 -> 'Andere'
      parentCompID = 0;
    }
    setNewData(filter_path, competencyID);
    button.style.display = "";// show back button
  }


  // Update data
  chart1.xAxis[0].categories = competencies;
  chart1.series[1].setData(chart1Data,true, true, false);
  chart1.series[0].setData(boxplotData);
  chart1a.xAxis[0].categories = competencies;
  chart1a.series[0].setData(chart1aDataComp,true, true, false);
  if(selected_userID){
    setUserDataChart1a(selected_userID)
  }
  chart1a.series[1].setData(chart1aDataUser);
  chart1b.xAxis[0].categories = competencies;
  chart1b.series[0].setData(chart1bData,true, true, false);
  chart2b1.series[0].setData(chart2b1_series0);
  chart2b2.series[0].setData(chart2b2_series0);
  chart2b2.series[1].setData(chart2b2_series1);
  
  // if filter on student, highlight student
  if (previousPoint2) {
    var index = chart1Data.map(function(e) { return e.id; }).indexOf(previousPoint2.id);
    if (index != -1){
      let point = chart1.series[1].data[index]; // find point that was already highlighted
      handleClick1(point,chart1);
    }
  }
 
  // Dynamic subtitles
  var parent = comp_course.filter(s => s.id === compID)
  if(parent.length == 1) {
    document.getElementById("subtitleChart1").innerHTML = parent[0].shortname;
    document.getElementById("subtitleChart2").innerHTML = parent[0].shortname;
  } else if (others) {
    document.getElementById("subtitleChart1").innerHTML = "In de groep 'Andere' vallen taken en toetsen die (nog) niet gelinkt zijn aan eindtermen.";
  } else {
    document.getElementById("subtitleChart1").innerHTML = "";
    document.getElementById("subtitleChart2").innerHTML = "";
  }
 // On lowest level: something are different (e.g. chart2b1 disappears and label not clickable anymore)
  if(currentLevelComp == 3) {
    document.getElementById("legchart2b1").style.display = "none"
    document.getElementById("container2b1").style.display = "none"
    chart2b2.update({ xAxis: {
      labels: { enabled: true } }  });

  } else {
    document.getElementById("legchart2b1").style.display = ""
    document.getElementById("container2b1").style.display = ""
    chart2b2.update({ xAxis: {
      labels: { enabled: false } }  });
    // Label of charts 1/1a/1b not clickable on lowest level
    clickLabel(chart1);
    clickLabel(chart1a);
    clickLabel(chart1b);
  }
  chart2b2.redraw(false);
  
} 

/* HELPER FUNCTIONS */

// Handler for competency labels of charts 1/1a/1b
function clickLabel(chart) {
  chart.xAxis[0].labelGroup.element.childNodes.forEach(function(label) {
  label.style.cursor = "pointer";
  label.style.color = 'rgb(240,248,255)';

  label.onmouseover = function() {
    label.style.fontWeight = 'bold';
    label.style.textDecoration ='underline'
    
  };
  label.onmouseout = function() {
    label.style.fontWeight = '';
    label.style.textDecoration =''
    
  };
  label.onclick = function() {
    var sub = 7;
    var compNoSpaces = this.textContent.replace( /\s/g, '').replace(/[^\x00-\x7F]/g, "").substring(0, 7); 
    if (compNoSpaces.length < 8) {
      sub = compNoSpaces.length;
    }
    var comp = comp_course.filter(element => (element.shortname.replace(/\s/g, "").substring(0, sub)) === compNoSpaces);
        
    if (comp.length == 1) {
      currentLevelComp += 1;
      breadcrumbChangeStyle(currentLevelComp);
      filterCompetency(comp[0].id); 
    } else {
      currentLevelComp = 3;
      breadcrumbChangeStyle(currentLevelComp);
      others = true;
      filterCompetency(-1); 
    }
      
};
 
    

  });
}


// Boxplot switch
function showBoxplot(){
  var series = chart1.series[0];
    if (series.visible) {
        series.hide();
    } else {
        series.show();
    }
}

/* SHOW DIFFERENT GRAPS WHEN USING RADIO BUTTON */
function showGrowth(){
  var view1 = document.getElementById("container3");
  var view2 = document.getElementById("insertHere");

  if (view1.style.display == "none") {
    
    view2.style.display = "none";
    view1.style.display = "";
    
  } else {
    
    view1.style.display = "none";
    view2.style.display = "";
  }
}

function showCHART1(chartID){
  var view1 = document.getElementById("container");
  var view2 = document.getElementById("container1a");
  var view3 = document.getElementById("container1b");
  var boxplot = document.getElementById("boxplot");


  if (chartID == 1) {
    view3.style.display = "none";
    view2.style.display = "none";
    view1.style.display = "";
    boxplot.style.display = "";
  } else if (chartID == 2)  {
    view3.style.display = "none";
    view1.style.display = "none";
    boxplot.style.display = "none";
    view2.style.display = "";
  } else {
    view1.style.display = "none";
    view2.style.display = "none";
    boxplot.style.display = "none";
    view3.style.display = "";
  }
}


/* BREADCRUMB FUNCTIONS */
function levelBack(){
  if (others) { // other jumps over building locks and end-terms (level 1 and 2) 
    currentLevelComp = 0
  } else {
    currentLevelComp += -1;
  }
  breadcrumbChangeStyle(currentLevelComp);
  others = false;
}

function breadcrumbLevel(requestedLevel){
  levelChange = currentLevelComp - requestedLevel;
  var compID;
  if (levelChange != 0) { // only when there is a change in level, not when you clich on current level
    if (requestedLevel == 0) {
      compID = 0;
      others = false;
    } else if (levelChange == 1){
      compID = parentCompID;
    } else {
      compID = comp_course_dict[parentCompID].path.split('/')[2]
    }
    currentLevelComp = requestedLevel;
    breadcrumbChangeStyle(currentLevelComp);
    filterCompetency(compID);
  }
  
  
}

function breadcrumbChangeStyle(level){
  var b0 = document.getElementById("breadcrumb0");
  var b1 = document.getElementById("breadcrumb1");
  var b2 = document.getElementById("breadcrumb2");
  var b3 = document.getElementById("breadcrumb3");

  var i1 = document.getElementById("breadcrumbicon1");
  var i2 = document.getElementById("breadcrumbicon2");
  var i3 = document.getElementById("breadcrumbicon3");

  all_bc = [b0,b1,b2,b3];
  all_bc.forEach(i => i.classList.remove("btn-currentLevel"))

  if (level == 0) {
    b0.classList.add("btn-currentLevel");
    b1.setAttribute('disabled', true)
    b2.setAttribute('disabled', true)
    b3.setAttribute('disabled', true)
    i1.style.color = '#959CA4'
    i2.style.color = '#959CA4'
    i3.style.color = '#959CA4'
    compText1 = "sleutelcompetentie"
    compText2 = "Sleutelcompetenties"
  } else if (level == 1) {
    b1.classList.add("btn-currentLevel");
    b1.removeAttribute('disabled')
    b2.setAttribute('disabled', true)
    b3.setAttribute('disabled', true)
    i1.style.color = '#0b2361'
    i2.style.color = '#959CA4'
    i3.style.color = '#959CA4'
    compText1 = "bouwsteen"
    compText2 = "Bouwstenen"
  } else if (level == 2) {
    b2.classList.add("btn-currentLevel");
    b2.removeAttribute('disabled')
    b3.setAttribute('disabled', true)
    i1.style.color = '#0b2361'
    i2.style.color = '#0b2361'
    i3.style.color = '#959CA4'
    compText1 = "eindterm"
    compText2 = "Eindtermen"
  } else {
    b3.classList.add("btn-currentLevel");
    b3.removeAttribute('disabled')
    i1.style.color = '#0b2361'
    i2.style.color = '#0b2361'
    i3.style.color = '#0b2361'
    compText1 = "toets/taak"
    compText2 = "Toetsen/taken"

  }
  document.getElementById("compLevel1").innerHTML = compText1;
  document.getElementById("compLevel2").innerHTML = compText2;
  document.getElementById("modalLevel1").innerHTML = compText1;
  document.getElementById("modalLevel2").innerHTML = compText2;
}












